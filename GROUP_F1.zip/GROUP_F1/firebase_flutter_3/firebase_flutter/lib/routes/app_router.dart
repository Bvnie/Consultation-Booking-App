import 'package:firebase_flutter/auth/admin_login_screen.dart';
import 'package:firebase_flutter/auth/student_login_screen.dart';
import 'package:firebase_flutter/auth/student_register_screen.dart';
import 'package:firebase_flutter/views/admin_profile_screen.dart';
import 'package:firebase_flutter/views/landing_page.dart';
import 'package:firebase_flutter/views/admin_dashboard.dart';
import 'package:firebase_flutter/auth/admin_register_screen.dart';
import 'package:firebase_flutter/views/booking_detail_screen.dart';
import 'package:firebase_flutter/views/booking_form_screen.dart';
import 'package:firebase_flutter/views/home_screen.dart';
import 'package:firebase_flutter/views/profile_screen.dart';
//import 'package:firebase_flutter/views/student_main_screen.dart';
import 'package:flutter/material.dart';



class RouteManager {
  static const String studentLogin = '/';
  static const String studentRegister = '/student-register';
  static const String adminRegister = '/admin-register';
  static const String adminLogin = '/admin-login';
  static const String adminProfile = '/admin-profile';
  static const String studentHome = '/student-home';
  static const String bookingForm = '/booking-form';
  static const String bookingDetail = '/booking-detail';
  static const String profile = '/profile';
  static const String adminDashboard = '/admin-dashboard';
  static const String studentMainScreen = '/student-main';
  static const String landingPage = '/landing-page';


  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case studentLogin:
        return MaterialPageRoute(builder: (_) => StudentLoginScreen());

      case studentRegister:
        return MaterialPageRoute(builder: (_) => StudentRegisterScreen());

        case adminLogin:
        return MaterialPageRoute(builder: (_) => AdminLoginScreen());

      case adminRegister:
        return MaterialPageRoute(builder: (_) => AdminRegisterScreen());

        case adminProfile:
        return MaterialPageRoute(builder: (_) => AdminProfileScreen());


      case studentHome:
        return MaterialPageRoute(builder: (_) => HomeScreen());

        //case studentMainScreen:
  //return MaterialPageRoute(builder: (_) => StudentMainScreen());

  case landingPage:
  return MaterialPageRoute(builder: (_) => LandingPage());

      case bookingForm:
        final String? bookingId = settings.arguments as String?;
        return MaterialPageRoute(
          builder: (_) => BookingFormScreen(bookingId: bookingId),
        );

      case bookingDetail:
        final String bookingId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => BookingDetailScreen(bookingId: bookingId),
        );

      case profile:
        return MaterialPageRoute(builder: (_) => ProfileScreen());

      case adminDashboard:
        return MaterialPageRoute(builder: (_) => AdminDashboard());

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}