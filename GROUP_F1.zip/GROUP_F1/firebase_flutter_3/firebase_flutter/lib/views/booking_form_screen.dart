import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class BookingFormScreen extends StatefulWidget {
  final String? bookingId; // null = new booking

  const BookingFormScreen({super.key, this.bookingId});

  @override
  _BookingFormScreenState createState() => _BookingFormScreenState();
}

class _BookingFormScreenState extends State<BookingFormScreen> {
  final _formKey = GlobalKey<FormState>();

  String? _selectedLecturer;
  DateTime? _selectedDateTime;
  final _topicController = TextEditingController();
  final _notesController = TextEditingController();

  bool _isLoading = false;
  final List<String> lecturers = [
    "Dr. Smith",
    "Prof. Lee",
    "Mr. Adams",
    "Ms. Johnson"
  ];

  @override
  void initState() {
    super.initState();
    if (widget.bookingId != null) {
      _loadBookingData();
    }
  }



  void _loadBookingData() async {
    DocumentSnapshot booking = await FirebaseFirestore.instance
        .collection('bookings')
        .doc(widget.bookingId)
        .get();
    var data = booking.data() as Map<String, dynamic>;
    setState(() {
      _selectedLecturer = data['lecturer'];
      _selectedDateTime = (data['datetime'] as Timestamp).toDate();
      _topicController.text = data['topic'];
      _notesController.text = data['notes'] ?? '';
    });
  }

  void _pickDateTime() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: now.add(Duration(days: 1)),
      firstDate: now,
      lastDate: DateTime(now.year + 1),
    );
    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (time == null) return;

    setState(() {
      _selectedDateTime = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate() || _selectedDateTime == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Please complete the form")));
      return;
    }

    setState(() => _isLoading = true);

    final user = FirebaseAuth.instance.currentUser;
    final studentDoc = await FirebaseFirestore.instance
        .collection('students')
        .doc(user!.uid)
        .get();
    final studentId = (studentDoc.data() as Map<String, dynamic>)['studentId'];

    final data = {
      'uid': user.uid,
      'studentId': studentId,
      'lecturer': _selectedLecturer,
      'datetime': Timestamp.fromDate(_selectedDateTime!),
      'topic': _topicController.text.trim(),
      'notes': _notesController.text.trim(),
      'status': 'pending',
    };

    if (widget.bookingId == null) {
      // New booking
      await FirebaseFirestore.instance.collection('bookings').add(data);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Booking saved")));
    } else {
      // Update
      await FirebaseFirestore.instance
          .collection('bookings')
          .doc(widget.bookingId)
          .update(data);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Booking updated")));
    }

    Navigator.pop(context);
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.bookingId == null ? "New Booking" : "Edit Booking", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: _selectedLecturer,
                decoration: InputDecoration(labelText: "Select Lecturer"),
                items: lecturers
                    .map((l) => DropdownMenuItem(value: l, child: Text(l)))
                    .toList(),
                onChanged: (val) => setState(() => _selectedLecturer = val),
                validator: (val) => val == null ? "Select a lecturer" : null,
              ),
              SizedBox(height: 10),
              ListTile(
                title: Text(_selectedDateTime == null
                    ? "Pick Date & Time"
                    : "Selected: ${_selectedDateTime.toString()}"),
                trailing: Icon(Icons.calendar_today),
                onTap: _pickDateTime,
              ),
              TextFormField(
                controller: _topicController,
                decoration: InputDecoration(labelText: "Consultation Topic"),
                minLines: 1,
                maxLines: 2,
                validator: (val) =>
                    val != null && val.length >= 20 ? null : "Max 20 characters",
              ),
              TextFormField(
                controller: _notesController,
                decoration: InputDecoration(labelText: "Additional Notes"),
                minLines: 2,
                maxLines: 4,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLoading ? null : _submitForm,
                child: _isLoading
                    ? CircularProgressIndicator()
                    : Text(widget.bookingId == null ? "Book Now" : "Update Booking"),
              )
            ],
          ),
        ),
      ),
    );
  }
}