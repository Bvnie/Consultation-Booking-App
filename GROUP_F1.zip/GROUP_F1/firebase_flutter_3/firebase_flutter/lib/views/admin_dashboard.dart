import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_flutter/auth/admin_login_screen.dart';
import 'package:firebase_flutter/routes/app_router.dart';
import 'package:flutter/material.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  DateTime? _startDate;
  DateTime? _endDate;
  String _searchStudentId = '';

  Stream<QuerySnapshot> _getBookingsStream() {
    CollectionReference bookings = FirebaseFirestore.instance.collection('bookings');
    Query query = bookings;

    // Apply search filter by studentId
    if (_searchStudentId.isNotEmpty) {
      query = query.where('studentId', isEqualTo: _searchStudentId.trim());
    }

    // Apply date range filter
    if (_startDate != null && _endDate != null) {
      query = query.where(
        'datetime',
        isGreaterThanOrEqualTo: Timestamp.fromDate(_startDate!),
        isLessThanOrEqualTo: Timestamp.fromDate(_endDate!.add(Duration(days: 1))),
      );
    }

    // Apply ordering only if search is not active (to avoid index issues)
    if (_searchStudentId.isEmpty) {
      query = query.orderBy('datetime', descending: true);
    }

    return query.snapshots();
  }

  Future<void> _deleteBooking(String bookingId) async {
    bool confirmed = await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Confirm Delete"),
        content: Text("Delete this booking permanently?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text("Delete"),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await FirebaseFirestore.instance.collection('bookings').doc(bookingId).delete();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Booking deleted")));
    }
  }

  Future<void> _confirmBooking(String bookingId) async {
    try {
      await FirebaseFirestore.instance.collection('bookings').doc(bookingId).update({'status': 'confirmed'});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Booking confirmed")));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Failed to confirm: $e")));
    }
  }

  String _formatTimestamp(Timestamp timestamp) {
    final dt = timestamp.toDate();
    return "${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute}";
  }

  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 1),
    );
    if (range != null) {
      setState(() {
        _startDate = range.start;
        _endDate = range.end;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text("Admin Dashboard", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            tooltip: "Profile",
            onPressed: () {
              Navigator.pushNamed(context, RouteManager.adminProfile);
            },
          ),
          IconButton(
            icon: Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const AdminLoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (val) {
                      setState(() => _searchStudentId = val);
                    },
                    decoration: InputDecoration(
                      labelText: "Search by Student ID",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton.icon(
                  onPressed: _pickDateRange,
                  icon: Icon(Icons.calendar_today),
                  label: Text("Filter by Date"),
                ),
              ],
            ),
            SizedBox(height: 10),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _getBookingsStream(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  final bookings = snapshot.data?.docs ?? [];

                  if (bookings.isEmpty) {
                    return Center(child: Text("No bookings found."));
                  }

                  return ListView.builder(
                    itemCount: bookings.length,
                    itemBuilder: (context, index) {
                      final doc = bookings[index];
                      final data = doc.data() as Map<String, dynamic>;
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 6),
                        child: ListTile(
                          title: Text(data['topic']),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Student ID: ${data['studentId']}"),
                              Text("Lecturer: ${data['lecturer']}"),
                              Text("Date/Time: ${_formatTimestamp(data['datetime'])}"),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (data['status'] != 'confirmed')
                                IconButton(
                                  icon: Icon(Icons.check, color: Colors.green),
                                  tooltip: 'Confirm Booking',
                                  onPressed: () => _confirmBooking(doc.id),
                                ),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                tooltip: 'Delete Booking',
                                onPressed: () => _deleteBooking(doc.id),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
