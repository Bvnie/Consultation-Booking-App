import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_flutter/views/booking_detail_screen.dart';
import 'package:firebase_flutter/views/booking_form_screen.dart';
import 'package:firebase_flutter/views/profile_screen.dart';
import 'package:firebase_flutter/auth/student_login_screen.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  User? user;

  @override
  void initState() {
    super.initState();
    user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      // Redirect to login screen if user is not logged in
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const StudentLoginScreen()),
        );
      });
    }
  }

  Future<void> _refreshBookings() async {
    setState(() {});
  }

  /// 🔎 This query requires a composite index:
  /// Firestore: bookings -> where('uid') -> orderBy('datetime')
  Stream<QuerySnapshot> getBookingsStream() {
    return FirebaseFirestore.instance
    .collection('bookings')
    .where('uid', isEqualTo: user?.uid)
    .snapshots();
  }

  String formatTimestamp(Timestamp ts) {
    final dt = ts.toDate();
    return "${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome, ${user!.email ?? user!.uid}", style: TextStyle(color: Colors.white),),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const StudentLoginScreen()),
              );
            },
          ),
        ],
        backgroundColor: Colors.blue,
      ),
      body: RefreshIndicator(
        onRefresh: _refreshBookings,
        child: StreamBuilder<QuerySnapshot>(
          stream: getBookingsStream(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(child: Text('No bookings found.'));
            }

            final bookings = snapshot.data!.docs;

            return ListView.builder(
              itemCount: bookings.length,
              itemBuilder: (context, index) {
                final booking = bookings[index];
                final data = booking.data() as Map<String, dynamic>;

                return ListTile(
                  title: Text(data['topic'] ?? 'No Title'),
                  subtitle: Text(
                    data.containsKey('datetime')
                        ? formatTimestamp(data['datetime'])
                        : 'No Date',
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            BookingDetailScreen(bookingId: booking.id),
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const BookingFormScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomAppBar(
        child: InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ProfileScreen()),
            );
          },
          child: const Padding(
            padding: EdgeInsets.all(12.0),
            child: Text(
              'View Profile',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.blue),
            ),
          ),
        ),
      ),
    );
  }
}
