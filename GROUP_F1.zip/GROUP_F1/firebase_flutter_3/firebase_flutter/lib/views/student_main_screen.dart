/*import 'package:firebase_flutter/views/booking_detail_screen.dart';
import 'package:firebase_flutter/views/home_screen.dart';
import 'package:firebase_flutter/views/profile_screen.dart';
import 'package:flutter/material.dart';


class StudentMainScreen extends StatefulWidget {
  const StudentMainScreen({super.key});

  @override
  _StudentMainScreenState createState() => _StudentMainScreenState();
}

class _StudentMainScreenState extends State<StudentMainScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    HomeScreen(),
    BookingDetailScreen(bookingId: '',), 
    ProfileScreen(),
  ];

  final List<String> _titles = ["Home", "Book", "Profile"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_titles[_currentIndex])),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        selectedItemColor: Colors.blueAccent,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.edit_calendar), label: "Book"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}*/