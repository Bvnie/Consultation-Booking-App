import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_flutter/views/booking_form_screen.dart';
import 'package:flutter/material.dart';


class BookingDetailScreen extends StatelessWidget {
  final String bookingId;

  const BookingDetailScreen({super.key, required this.bookingId});

  Future<void> _deleteBooking(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Delete Booking"),
        content: Text("Are you sure you want to delete this booking?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Cancel")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Delete")),
        ],
      ),
    );

    if (confirmed == true) {
      await FirebaseFirestore.instance.collection('bookings').doc(bookingId).delete();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Booking deleted")));
      Navigator.pop(context);
    }
  }

  String formatTimestamp(Timestamp ts) {
    final dt = ts.toDate();
    return "${dt.day}/${dt.month}/${dt.year} at ${dt.hour}:${dt.minute}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking Details", style: TextStyle(color: Colors.white),),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BookingFormScreen(bookingId: bookingId),
                ),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _deleteBooking(context),
          )
        ],
        backgroundColor: Colors.blue,
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('bookings').doc(bookingId).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return Center(child: Text("Booking not found"));
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView(
              children: [
                ListTile(
                  leading: Icon(Icons.person),
                  title: Text("Lecturer"),
                  subtitle: Text(data['lecturer']),
                ),
                ListTile(
                  leading: Icon(Icons.calendar_today),
                  title: Text("Date & Time"),
                  subtitle: Text(formatTimestamp(data['datetime'])),
                ),
                ListTile(
                  leading: Icon(Icons.topic),
                  title: Text("Topic"),
                  subtitle: Text(data['topic']),
                ),
                ListTile(
                  leading: Icon(Icons.notes),
                  title: Text("Notes"),
                  subtitle: Text(data['notes'] ?? "-"),
                ),
                ListTile(
                  leading: Icon(Icons.info),
                  title: Text("Status"),
                  subtitle: Text(data['status']),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}