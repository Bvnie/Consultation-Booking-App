import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final user = FirebaseAuth.instance.currentUser!;
  bool isEditing = false;

  final _studentIdController = TextEditingController();
  final _emailController = TextEditingController();
  final _contactController = TextEditingController();
  String? profileImageUrl;
  File? newImageFile;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    DocumentSnapshot snapshot = await FirebaseFirestore.instance
        .collection('students')
        .doc(user.uid)
        .get();

    final data = snapshot.data() as Map<String, dynamic>;

    setState(() {
      _studentIdController.text = data['studentId'] ?? '';
      _emailController.text = data['email'] ?? '';
      _contactController.text = data['contact'] ?? '';
      profileImageUrl = data['profileImageUrl'];
    });
  }

  Future<void> _pickImage() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        newImageFile = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadProfilePicture() async {
    if (newImageFile == null) return profileImageUrl;
    final ref = FirebaseStorage.instance
        .ref()
        .child("profile_pics")
        .child("${user.uid}.jpg");
    await ref.putFile(newImageFile!);
    return await ref.getDownloadURL();
  }

  Future<void> _saveChanges() async {
    final newUrl = await _uploadProfilePicture();

    await FirebaseFirestore.instance
        .collection('students')
        .doc(user.uid)
        .update({
      'studentId': _studentIdController.text.trim(),
      'email': _emailController.text.trim(),
      'contact': _contactController.text.trim(),
      'profileImageUrl': newUrl,
    });

    setState(() {
      isEditing = false;
      profileImageUrl = newUrl;
      newImageFile = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Profile updated")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final avatar = newImageFile != null
        ? FileImage(newImageFile!)
        : (profileImageUrl != null
            ? NetworkImage(profileImageUrl!)
            : AssetImage('assets/default_avatar.png') as ImageProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Profile",
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: Icon(isEditing ? Icons.save : Icons.edit),
            onPressed: () {
              if (isEditing) {
                _saveChanges();
              } else {
                setState(() => isEditing = true);
              }
            },
          )
        ],
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              GestureDetector(
                onTap: isEditing ? _pickImage : null,
                child: CircleAvatar(
                  backgroundImage: avatar,
                  radius: 50,
                ),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _studentIdController,
                readOnly: !isEditing,
                decoration: InputDecoration(labelText: "Student ID"),
              ),
              TextFormField(
                controller: _emailController,
                readOnly: !isEditing,
                decoration: InputDecoration(labelText: "Email"),
              ),
              TextFormField(
                controller: _contactController,
                readOnly: !isEditing,
                decoration: InputDecoration(labelText: "Contact Number"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
