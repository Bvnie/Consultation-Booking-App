import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AdminProfileScreen extends StatefulWidget {
  const AdminProfileScreen({super.key});

  @override
  State<AdminProfileScreen> createState() => _AdminProfileScreenState();
}

class _AdminProfileScreenState extends State<AdminProfileScreen> {
  final user = FirebaseAuth.instance.currentUser!;
  bool isEditing = false;

  final _emailController = TextEditingController();
  final _contactController = TextEditingController();
  final _adminIdController = TextEditingController();

  String? profileImageUrl;
  File? newImageFile;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final doc = await FirebaseFirestore.instance.collection('admins').doc(user.uid).get();

    if (!doc.exists) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Admin profile not found.")),
      );
      return;
    }

    final data = doc.data();
    print("Loaded profile: $data"); // Debug

    if (data != null) {
      setState(() {
        _adminIdController.text = data['adminId'] ?? '';
        _emailController.text = data['email'] ?? '';
        _contactController.text = data['contact'] ?? '';
        profileImageUrl = data['profileImageUrl'];
      });
    }
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        newImageFile = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadProfilePicture() async {
    if (newImageFile == null) return profileImageUrl;
    final ref = FirebaseStorage.instance
        .ref()
        .child("profile_pics")
        .child("${user.uid}.jpg");
    await ref.putFile(newImageFile!);
    return await ref.getDownloadURL();
  }

  Future<void> _saveChanges() async {
    final newUrl = await _uploadProfilePicture();

    await FirebaseFirestore.instance.collection('admins').doc(user.uid).update({
      'email': _emailController.text.trim(),
      'contact': _contactController.text.trim(),
      'profileImageUrl': newUrl,
    });

    setState(() {
      isEditing = false;
      profileImageUrl = newUrl;
      newImageFile = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Profile updated")));
  }

  @override
  Widget build(BuildContext context) {
    final avatar = newImageFile != null
        ? FileImage(newImageFile!)
        : (profileImageUrl != null
            ? NetworkImage(profileImageUrl!)
            : AssetImage('assets/default_avatar.png') as ImageProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text("Profile", style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            icon: Icon(isEditing ? Icons.save : Icons.edit),
            onPressed: () {
              if (isEditing) {
                _saveChanges();
              } else {
                setState(() => isEditing = true);
              }
            },
          )
        ],
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              GestureDetector(
                onTap: isEditing ? _pickImage : null,
                child: CircleAvatar(
                  backgroundImage: avatar,
                  radius: 50,
                ),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _adminIdController,
                readOnly: true,
                decoration: InputDecoration(labelText: "Admin ID"),
              ),
              TextField(
                controller: _emailController,
                readOnly: !isEditing,
                decoration: InputDecoration(labelText: "Email"),
              ),
              TextField(
                controller: _contactController,
                readOnly: !isEditing,
                decoration: InputDecoration(labelText: "Contact Number"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
