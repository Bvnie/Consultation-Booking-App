import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String id;
  final String uid;
  final String studentId;
  final String lecturer;
  final String topic;
  final String notes;
  final Timestamp datetime;
  final String status;

  BookingModel({
    required this.id,
    required this.uid,
    required this.studentId,
    required this.lecturer,
    required this.topic,
    required this.notes,
    required this.datetime,
    required this.status,
  });

  factory BookingModel.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return BookingModel(
      id: doc.id,
      uid: data['uid'],
      studentId: data['studentId'],
      lecturer: data['lecturer'],
      topic: data['topic'],
      notes: data['notes'],
      datetime: data['datetime'],
      status: data['status'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'studentId': studentId,
      'lecturer': lecturer,
      'topic': topic,
      'notes': notes,
      'datetime': datetime,
      'status': status,
    };
  }
}