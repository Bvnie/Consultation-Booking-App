class AdminModel {
  final String uid;
  final String adminId;
  final String email;
  final String contact;
  final String? profileImageUrl;

  AdminModel({
    required this.uid,
    required this.adminId,
    required this.email,
    required this.contact,
    this.profileImageUrl,
  });

  factory AdminModel.fromMap(Map<String, dynamic> data) {
    return AdminModel(
      uid: data['uid'],
      adminId: data['adminId'],
      email: data['email'],
      contact: data['contact'],
      profileImageUrl: data['profileImageUrl'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'adminId': adminId,
      'email': email,
      'contact': contact,
      'profileImageUrl': profileImageUrl,
    };
  }
}
// This class is used to represent a user in the application. It contains fields for the user's email, name, and the date they were created.
// The class provides a factory method to create an instance from Firestore document data and a method to convert the instance back to a format suitable for Firestore storage.
// This allows for easy serialization and deserialization of user data when interacting with Firestore, ensuring that the data is stored and retrieved correctly.
// The class is designed to be used in conjunction with Firebase Authentication and Firestore, making it a crucial part of the user management system in the application.
// The AppUser class is essential for managing user data and ensuring that the application can effectively handle user authentication and storage.
//     return 'An error occurred. Please try again.'; // Generic error message for other cases

