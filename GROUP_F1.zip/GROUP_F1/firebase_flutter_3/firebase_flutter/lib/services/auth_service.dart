import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_flutter/models/booking_model.dart';
import 'package:firebase_flutter/models/student_model.dart';
import 'package:flutter/foundation.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Access current user
  User? get currentUser => _auth.currentUser;

  // 🔐 Login method (for both student/admin)
  Future<User?> login(String email, String password) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      throw _authError(e.code);
    }
  }

  // 🧑‍🎓 Student Registration
  Future<void> registerStudent({
    required String email,
    required String password,
    required String studentId,
    required String contact,
  }) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      await _firestore.collection('students').doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'studentId': studentId,
        'email': email,
        'contact': contact,
        'profileImageUrl': null,
      });

    } on FirebaseAuthException catch (e) {
      throw _authError(e.code);
    }
  }

  // 🛡️ Admin Registration
  Future<void> registerAdmin({
    required String email,
    required String password,
  }) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      await _firestore.collection('admins').doc(userCredential.user!.uid).set({
        'uid': userCredential.user!.uid,
        'email': email,
        'isAdmin': true,
      });

    } on FirebaseAuthException catch (e) {
      throw _authError(e.code);
    }
  }

  // 🔄 Logout
  Future<void> logout() async {
    await _auth.signOut();
  }

  // 🔐 Auth error messages
  String _authError(String code) {
    switch (code) {
      case 'invalid-email':
        return 'Invalid email format.';
      case 'email-already-in-use':
        return 'This email is already in use.';
      case 'user-not-found':
        return 'No user found.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'weak-password':
        return 'Password must be 8+ chars and include "@"';
      default:
        return 'Authentication failed.';
    }
  }

  // ✅ Get student data
  Future<StudentModel?> getStudentData() async {
    if (currentUser == null) return null;

    final doc = await _firestore.collection('students').doc(currentUser!.uid).get();
    if (doc.exists) {
      return StudentModel.fromMap(doc.data() as Map<String, dynamic>);
    }
    return null;
  }

  // 🔄 Update student profile
  Future<void> updateProfile({
    required String email,
    required String contact,
    String? profileImageUrl,
  }) async {
    await _firestore.collection('students').doc(currentUser!.uid).update({
      'email': email,
      'contact': contact,
      'profileImageUrl': profileImageUrl,
    });
    notifyListeners();
  }

  // 🧾 Get student bookings
  Stream<List<BookingModel>> getStudentBookings() {
    if (currentUser == null) throw Exception('User not authenticated');

    return _firestore
        .collection('bookings')
        .where('uid', isEqualTo: currentUser!.uid)
        .orderBy('datetime')
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => BookingModel.fromDoc(doc)).toList());
  }
}
