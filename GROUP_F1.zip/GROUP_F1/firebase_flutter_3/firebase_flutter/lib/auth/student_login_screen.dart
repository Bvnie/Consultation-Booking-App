import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_flutter/views/home_screen.dart';
import 'package:firebase_flutter/auth/student_register_screen.dart';
import 'package:flutter/material.dart';

class StudentLoginScreen extends StatefulWidget{
  const StudentLoginScreen({super.key});

  @override
  _StudentLoginScreenState createState() => _StudentLoginScreenState();
}

class _StudentLoginScreenState extends State< StudentLoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _isLoading = false;
  bool _rememberMe = false;

  void loginUser() async {
    setState(() => _isLoading = true);
    try{
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Login successful")));

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => HomeScreen()),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Login failed: ${e.toString()}")));
    }
    setState(() => _isLoading = false);
  }

  void resetPassword() async {
    if(_emailController.text.trim().isEmpty || !_emailController.text.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Enter valid email to reset")));
      return;
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: _emailController.text.trim(),
        );
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Password reset email sent")));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error ${e.toString()}")));
    }
  }

  

  @override 
  Widget build(BuildContext content) {
    return Scaffold(
    appBar: AppBar(title: Text("Student Login",style: TextStyle(color: Colors.white),), backgroundColor: Colors.blue,),
    body: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _emailController,
            decoration: InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: "Password"),
            ),
            Row(
              children: [
                Checkbox(
                  value: _rememberMe,
                  onChanged: (val) {
                    setState(() => _rememberMe = val!);
                  },
                  ),
                  Text("Remember me"),
              ],
              ),
              ElevatedButton(
                onPressed: _isLoading ? null : loginUser,
                child: _isLoading ? CircularProgressIndicator() : Text ("Login"),
              ),
              TextButton(
                onPressed: resetPassword,
                child: Text("Forgot password?"),
              ),
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => StudentRegisterScreen()),
                  );
                },
                child: Text("Don't have an account? Register"), 
              )
              
        ],
        ),
      ),
    );
  }

}