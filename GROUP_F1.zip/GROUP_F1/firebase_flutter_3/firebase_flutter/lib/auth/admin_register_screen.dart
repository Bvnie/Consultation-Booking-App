import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class AdminRegisterScreen extends StatefulWidget{
  const AdminRegisterScreen({super.key});

    @override
    _AdminRegisterScreenState createState() => _AdminRegisterScreenState();
}

class _AdminRegisterScreenState extends State<AdminRegisterScreen>{
    final _formKey =  GlobalKey<FormState>();
    final TextEditingController _adminIdController = TextEditingController();
    final TextEditingController _emailController = TextEditingController();
    final TextEditingController _passwordController = TextEditingController();
    final TextEditingController _contactController = TextEditingController();

    bool _isLoading = false;
    Future <bool> isStudentIdUnique(String id)async{
      var snapshot = await FirebaseFirestore.instance.collection('admin').where('adminId', isEqualTo: id).get();
      return snapshot.docs.isEmpty;
    }

    void registerStudent() async{
      if(!_formKey.currentState!.validate())return;

      setState(() => _isLoading = true);
      bool unique = await isStudentIdUnique(_adminIdController.text.trim());
      if(!unique){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Admin Id already exists")));
        setState(() => _isLoading = false);
        return;
      }

      try{
        UserCredential user = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: _emailController.text.trim(), password: _passwordController.text.trim(),);
        await FirebaseFirestore.instance.collection('admin').doc(user.user!.uid).set({
          'adminId': _adminIdController.text.trim(),
           'email': _emailController.text.trim(),
            'contact': _contactController.text.trim(),
            'uid':user.user!.uid,
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Registration Successful")));
        Navigator.pop(context);
      }
      catch(e){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: ${e.toString()}")));
      }
      setState(() => _isLoading = false);
    }
    @override
    Widget build(BuildContext context){
      return Scaffold(
        appBar: AppBar(
          title: Text('Admin Registration', style: TextStyle(color: Colors.white),),
          backgroundColor: Colors.blue,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _adminIdController,
                decoration: InputDecoration(labelText: 'Admin ID'),
                validator: (value) => value == null || value.isEmpty ? "Enter Admin ID" : null,
              ),
               TextFormField(
                controller: _emailController,
                decoration: InputDecoration(labelText: 'Email'),
                validator: (value) => value != null && value.contains('@') ? null : "Invalid Email",
              ),
               TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (value) {
                  if(value == null || value.length<8 || !value.contains('@')){
                    return "Password must be 8+ characters and include '@' ";
                  }
                  return null;
                },
              ),
               TextFormField(
                controller: _contactController,
                decoration: InputDecoration(labelText: 'Contact Number'),
                validator: (value) => value == null || value.isEmpty ? "Enter Contact Number" : null,
              ),
              SizedBox(height: 20,),
              ElevatedButton(onPressed: _isLoading ? null : registerStudent , child: _isLoading? CircularProgressIndicator() : Text("Register"),)
            ],
          ),
          )
          ),
      );
    }
}